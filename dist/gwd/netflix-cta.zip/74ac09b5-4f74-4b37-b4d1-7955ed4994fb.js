
/* wc-netflix-cta:74ac09b5-4f74-4b37-b4d1-7955ed4994fb.js, VERSION: 4.0.1, Published: 2018/11/27 11:33:08 $*/
// GENERIC SOURCE TRACKER: wc-netflix-cta
if (typeof module === 'undefined') {
  module = {};
}
// prettier-ignore
module.exports = {
  "id": "74ac09b5-4f74-4b37-b4d1-7955ed4994fb",
  "name": "wc-netflix-cta",
  "description": "CTA button",
  "type": "web_components",
  "context": "Default",
  "state": "published",
  "updated": 1537816581909,
  "full_name": "NetflixAdsEng/wc-netflix-cta",
  "html_url": "https://github.com/NetflixAdsEng/wc-netflix-cta",
  "username": "GitHub",
  "version": "4.0.1",
  "minimum": "3.0.0"
}
