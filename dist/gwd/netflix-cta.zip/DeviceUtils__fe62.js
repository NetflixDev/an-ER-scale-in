
/* wc-netflix-cta:DeviceUtils__fe62.js, VERSION: 3.0.1, Published: 2018/05/31 15:49:34 $*/
window.Utils = window.Utils || {}

Utils.isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

Utils.isiOS    = /iPad|iPhone|iPod/.test(navigator.userAgent);
Utils.isiOS9up = Utils.isiOS && ((navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/)[1] > 9);
Utils.isiPad   = /iPad/.test(navigator.userAgent);
Utils.isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);