
/* an-ER-scale-in:25fd746d-ca30-41d7-b005-4bcd499d6335.js, VERSION: 1.0.0, Published: 2019/08/14 12:05:37 $*/
// GENERIC SOURCE TRACKER: an-ER-scale-in
if (typeof module === 'undefined') {
  module = {};
}
// prettier-ignore
module.exports = {
  "id": "25fd746d-ca30-41d7-b005-4bcd499d6335",
  "name": "an-ER-scale-in",
  "description": "CTA button",
  "type": "animations",
  "context": "Default",
  "state": "published",
  "updated": 1544728889095,
  "full_name": "NetflixDev/an-ER-scale-in",
  "html_url": "https://github.com/NetflixDev/an-ER-scale-in",
  "username": "GitHub",
  "version": "1.0.0",
  "minimum": "1.0.0"
}
