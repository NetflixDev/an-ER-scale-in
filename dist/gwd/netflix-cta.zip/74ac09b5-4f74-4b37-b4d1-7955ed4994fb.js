
/* an-test:74ac09b5-4f74-4b37-b4d1-7955ed4994fb.js, VERSION: 5.0.0, Published: 2019/02/12 12:30:44 $*/
// GENERIC SOURCE TRACKER: an-test
if (typeof module === 'undefined') {
  module = {};
}
// prettier-ignore
module.exports = {
  "id": "74ac09b5-4f74-4b37-b4d1-7955ed4994fb",
  "name": "an-test",
  "description": "CTA button",
  "type": "animations",
  "context": "Default",
  "state": "published",
  "updated": 1544728889095,
  "full_name": "NetflixAdsEng/an-test",
  "html_url": "https://github.com/NetflixAdsEng/an-test",
  "username": "GitHub",
  "version": "5.0.0",
  "minimum": "3.0.0"
}
