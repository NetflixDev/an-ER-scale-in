// GENERIC SOURCE TRACKER: wc-netflix-cta
if (typeof module === 'undefined') {
	module = {}
}

module.exports = {
  "id": "74ac09b5-4f74-4b37-b4d1-7955ed4994fb",
  "name": "wc-netflix-cta",
  "description": "CTA button",
  "type": "web_components",
  "context": "Default",
  "state": "published",
  "updated": 1517619727496,
  "full_name": "NetflixAdsEng/wc-netflix-cta",
  "html_url": "https://github.com/NetflixAdsEng/wc-netflix-cta",
  "username": "GitHub",
  "version": "1.1.4"
}
